//CREATING THE LISTENER - to add new object 
$("#clearInput").click(function(){
        $("#input1").val("");
        $("#input2").val("");
        $("#input3").val("");
});

$("#submitInput").click(function(){
    alert("Submit Button was Pressed.");
});